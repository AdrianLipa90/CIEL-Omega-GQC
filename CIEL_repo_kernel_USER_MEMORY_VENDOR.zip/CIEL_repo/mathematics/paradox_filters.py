# auto-generated wrapper (no placeholders)

from ..ext.ext5 import ParadoxFilters
__all__ = ['ParadoxFilters']