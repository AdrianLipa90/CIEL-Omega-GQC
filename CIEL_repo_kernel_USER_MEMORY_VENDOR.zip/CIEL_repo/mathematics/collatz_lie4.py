# auto-generated wrapper (no placeholders)

from ..ext.ext18 import CollatzLie4Engine
__all__ = ['CollatzLie4Engine']