# auto-generated wrapper (no placeholders)

from ..ext.extfwcku import safe_inv
__all__ = ['safe_inv']