# Core Api

CIEL/0 Complete Unified Framework Implementation
Adrian Lipa's Theory of Everything - Complete Implementation