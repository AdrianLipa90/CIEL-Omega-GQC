# auto-generated wrapper (no placeholders)

from ..ext.ext1 import KernelSpec
__all__ = ['KernelSpec']