# auto-generated wrapper (no placeholders)

from ..ext.ext1 import CielConfig
__all__ = ['CielConfig']