# auto-generated wrapper (no placeholders)

from ..ext.extfwcku import GlyphCompiler
__all__ = ['GlyphCompiler']