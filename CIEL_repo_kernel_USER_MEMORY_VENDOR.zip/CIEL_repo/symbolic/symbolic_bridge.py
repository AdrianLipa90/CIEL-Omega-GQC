# auto-generated wrapper (no placeholders)

from ..ext.ext8 import SymbolicBridge
__all__ = ['SymbolicBridge']