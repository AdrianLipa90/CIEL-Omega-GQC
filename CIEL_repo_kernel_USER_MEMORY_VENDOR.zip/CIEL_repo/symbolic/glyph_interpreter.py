# auto-generated wrapper (no placeholders)

from ..ext.ext8 import GlyphNodeInterpreter
__all__ = ['GlyphNodeInterpreter']