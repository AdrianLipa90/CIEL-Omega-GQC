# auto-generated wrapper (no placeholders)

from ..ext.ext8 import CVOSDatasetLoader
__all__ = ['CVOSDatasetLoader']