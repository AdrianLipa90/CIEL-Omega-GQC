# auto-generated wrapper (no placeholders)

from ..ext.ext3 import EthicsLogger
__all__ = ['EthicsLogger']