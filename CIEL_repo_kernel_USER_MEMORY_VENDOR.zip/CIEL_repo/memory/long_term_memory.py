# auto-generated wrapper (no placeholders)

from ..ext.ext18 import LongTermMemory
__all__ = ['LongTermMemory']