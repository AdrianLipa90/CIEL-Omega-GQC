# auto-generated wrapper (no placeholders)

from ..ext.ext21 import AdamMemoryKernel
__all__ = ['AdamMemoryKernel']