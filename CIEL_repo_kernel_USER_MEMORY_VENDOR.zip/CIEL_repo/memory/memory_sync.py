# auto-generated wrapper (no placeholders)

from ..ext.ext19 import MemorySync
__all__ = ['MemorySync']