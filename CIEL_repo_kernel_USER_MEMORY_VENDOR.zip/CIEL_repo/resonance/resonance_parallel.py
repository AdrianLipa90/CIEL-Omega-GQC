# auto-generated wrapper (no placeholders)

from ..ext.ext18 import ResConnectParallel
__all__ = ['ResConnectParallel']