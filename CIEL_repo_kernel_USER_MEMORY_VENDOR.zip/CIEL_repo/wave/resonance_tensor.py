# auto-generated wrapper (no placeholders)

from ..ext.extfwcku import MultiresonanceTensor
__all__ = ['MultiresonanceTensor']