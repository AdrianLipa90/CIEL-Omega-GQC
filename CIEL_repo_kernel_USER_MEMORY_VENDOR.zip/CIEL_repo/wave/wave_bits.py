# auto-generated wrapper (no placeholders)

from ..ext.extfwcku import WaveBit3D
from ..ext.extfwcku import ConsciousWaveBit3D
__all__ = ['WaveBit3D', 'ConsciousWaveBit3D']