# auto-generated wrapper (no placeholders)

from ..ext.extfwcku import IntentionField
__all__ = ['IntentionField']