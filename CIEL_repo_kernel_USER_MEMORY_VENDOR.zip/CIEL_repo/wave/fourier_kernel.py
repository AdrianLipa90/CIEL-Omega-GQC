# auto-generated wrapper (no placeholders)

from ..ext.extfwcku import SpectralWaveField12D
__all__ = ['SpectralWaveField12D']