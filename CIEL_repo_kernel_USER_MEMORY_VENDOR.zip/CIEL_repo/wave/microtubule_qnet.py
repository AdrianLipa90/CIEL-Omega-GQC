# auto-generated wrapper (no placeholders)

from ..ext.extfwcku import MicrotubuleQNet
__all__ = ['MicrotubuleQNet']