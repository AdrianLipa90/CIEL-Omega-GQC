# auto-generated wrapper (no placeholders)

from ..ext.ext17 import OmegaBootRitual
__all__ = ['OmegaBootRitual']