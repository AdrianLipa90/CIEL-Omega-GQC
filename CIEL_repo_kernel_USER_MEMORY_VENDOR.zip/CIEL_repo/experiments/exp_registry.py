# auto-generated wrapper (no placeholders)

from ..ext.ext17 import ExpRegistry
__all__ = ['ExpRegistry']