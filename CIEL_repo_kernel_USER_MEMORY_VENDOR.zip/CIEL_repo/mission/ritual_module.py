# auto-generated wrapper (no placeholders)

from ..ext.ext21 import RitualModule
__all__ = ['RitualModule']