# auto-generated wrapper (no placeholders)

from ..ext.ext9 import EmpathicEngine
__all__ = ['EmpathicEngine']