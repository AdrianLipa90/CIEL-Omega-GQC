# auto-generated wrapper (no placeholders)

from ..ext.ext9 import EEGEmotionMapper
__all__ = ['EEGEmotionMapper']