# auto-generated wrapper (no placeholders)

from ..ext.ext9 import EmotionCore
__all__ = ['EmotionCore']