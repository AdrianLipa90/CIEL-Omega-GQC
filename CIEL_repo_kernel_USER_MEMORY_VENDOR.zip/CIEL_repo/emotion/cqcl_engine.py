# auto-generated wrapper (no placeholders)

from ..ext.extemot import CIEL_Quantum_Engine
__all__ = ['CIEL_Quantum_Engine']