# auto-generated wrapper (no placeholders)

from ..ext.extemot import EmotionalCollatzEngine
__all__ = ['EmotionalCollatzEngine']