# auto-generated wrapper (no placeholders)

from ..ext.ext9 import FeelingField
__all__ = ['FeelingField']