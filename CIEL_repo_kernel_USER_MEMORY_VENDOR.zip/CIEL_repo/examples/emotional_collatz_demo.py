from emotion.emotional_collatz import EmotionalCollatzEngine
print('emotional_collatz_demo ok')
