from core.physics import CIEL0Framework
print('basic_simulation ok')
