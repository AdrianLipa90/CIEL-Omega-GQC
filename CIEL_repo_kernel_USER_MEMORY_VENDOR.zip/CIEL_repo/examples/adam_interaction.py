from memory.adam_memory import AdamMemoryKernel
print('adam_interaction ok')
