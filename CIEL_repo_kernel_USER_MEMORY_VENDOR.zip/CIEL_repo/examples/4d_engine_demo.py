from universal_law_4d.universal_engine import UniversalLawEngine4D
print('4d_engine_demo ok')
