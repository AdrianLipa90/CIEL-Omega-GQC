from wave.fourier_kernel import SpectralWaveField12D
print('fourier_wave_demo ok')
