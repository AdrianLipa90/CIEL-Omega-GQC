# auto-generated wrapper (no placeholders)

from ..ext.ext18 import DissociationAnalyzer
__all__ = ['DissociationAnalyzer']