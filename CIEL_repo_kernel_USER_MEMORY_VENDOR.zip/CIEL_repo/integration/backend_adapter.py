# auto-generated wrapper (no placeholders)

from ..ext.ext20 import BackendAdapter
__all__ = ['BackendAdapter']