# auto-generated wrapper (no placeholders)

from ..ext.ext19 import BackendGlue
__all__ = ['BackendGlue']