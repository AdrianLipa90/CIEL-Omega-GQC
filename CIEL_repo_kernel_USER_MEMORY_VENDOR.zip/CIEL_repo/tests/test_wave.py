
def test_wave_imports():
    from wave.fourier_kernel import SpectralWaveField12D
    assert SpectralWaveField12D is not None
