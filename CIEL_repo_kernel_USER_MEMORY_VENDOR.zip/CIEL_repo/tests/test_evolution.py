
def test_evolution_imports():
    from evolution.omega_drift import OmegaDriftCore as _x
    assert _x is not None
