# auto-generated wrapper (no placeholders)

from ..ext.ext1 import GPUEngine
__all__ = ['GPUEngine']