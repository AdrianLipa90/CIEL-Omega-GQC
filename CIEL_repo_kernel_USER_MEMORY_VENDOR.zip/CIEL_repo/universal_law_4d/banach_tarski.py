# auto-generated wrapper (no placeholders)

from ..universal_law_4d.universal_engine import BanachTarskiCreation4D
__all__ = ['BanachTarskiCreation4D']