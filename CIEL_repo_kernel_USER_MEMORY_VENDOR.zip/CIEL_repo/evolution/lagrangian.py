# auto-generated wrapper (no placeholders)

from ..ext.definitekernel import UnifiedRealityLaws
__all__ = ['UnifiedRealityLaws']