# auto-generated wrapper (no placeholders)

from ..ext.ext20 import RCDECalibrator
__all__ = ['RCDECalibrator']