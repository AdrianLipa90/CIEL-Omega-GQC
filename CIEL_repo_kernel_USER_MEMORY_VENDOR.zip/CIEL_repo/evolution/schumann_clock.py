# auto-generated wrapper (no placeholders)

from ..ext.ext18 import SchumannClock
__all__ = ['SchumannClock']