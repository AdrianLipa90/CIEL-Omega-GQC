# auto-generated wrapper (no placeholders)

from ..ext.ext19 import CSF2Kernel
__all__ = ['CSF2Kernel']