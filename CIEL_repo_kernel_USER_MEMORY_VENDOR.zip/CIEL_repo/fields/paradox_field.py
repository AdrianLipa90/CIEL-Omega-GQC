# auto-generated wrapper (no placeholders)

from ..ext.paradoxes import UltimateParadoxOperators
__all__ = ['UltimateParadoxOperators']