# auto-generated wrapper (no placeholders)

from ..ext.paradoxes import UltimateRealityLayer
__all__ = ['UltimateRealityLayer']