# auto-generated wrapper (no placeholders)

from ..ext.ext4 import ColorMap
__all__ = ['ColorMap']