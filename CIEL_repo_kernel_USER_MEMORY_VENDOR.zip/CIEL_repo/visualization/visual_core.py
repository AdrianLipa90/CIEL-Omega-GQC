# auto-generated wrapper (no placeholders)

from ..ext.ext5 import VisualCore
__all__ = ['VisualCore']