# auto-generated wrapper (no placeholders)

from ..ext.ext1 import EthicsGuard
__all__ = ['EthicsGuard']