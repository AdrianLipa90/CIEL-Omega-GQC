# auto-generated wrapper (no placeholders)

from ..ext.extfwcku import Lambda0Operator
__all__ = ['Lambda0Operator']