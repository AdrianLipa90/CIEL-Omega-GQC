# auto-generated wrapper (no placeholders)

from ..ext.ext4 import EthicalEngine
__all__ = ['EthicalEngine']