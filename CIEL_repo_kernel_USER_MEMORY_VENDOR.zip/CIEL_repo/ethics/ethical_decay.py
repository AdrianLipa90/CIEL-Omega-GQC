# auto-generated wrapper (no placeholders)

from ..ext.ext4 import EthicalDecay
__all__ = ['EthicalDecay']