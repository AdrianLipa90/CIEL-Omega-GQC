# auto-generated wrapper (no placeholders)

from ..ext.ext7 import EEGProcessor
__all__ = ['EEGProcessor']