# auto-generated wrapper (no placeholders)

from ..ext.ext7 import CrystalFieldReceiver
__all__ = ['CrystalFieldReceiver']