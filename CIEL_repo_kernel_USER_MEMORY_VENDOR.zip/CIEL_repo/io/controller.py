# auto-generated wrapper (no placeholders)

from ..ext.ext7 import RealTimeController
__all__ = ['RealTimeController']