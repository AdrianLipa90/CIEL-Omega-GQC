# auto-generated wrapper (no placeholders)

from ..ext.ext3 import DataLoader
__all__ = ['DataLoader']