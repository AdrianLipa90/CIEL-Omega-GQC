# auto-generated wrapper (no placeholders)

from ..ext.ext3 import RealityLogger
__all__ = ['RealityLogger']