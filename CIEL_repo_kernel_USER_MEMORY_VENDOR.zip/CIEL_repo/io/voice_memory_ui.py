# auto-generated wrapper (no placeholders)

from ..ext.ext7 import VoiceMemoryUI
__all__ = ['VoiceMemoryUI']