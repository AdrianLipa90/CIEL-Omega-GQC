# auto-generated wrapper (no placeholders)

from ..mathematics.lie4_engine import UnifiedSevenFundamentalFields
__all__ = ['UnifiedSevenFundamentalFields']