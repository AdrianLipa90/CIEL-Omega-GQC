# auto-generated wrapper (no placeholders)
