# auto-generated wrapper (no placeholders)

from ..mathematics.lie4_engine import UnifiedCIELConstants
__all__ = ['UnifiedCIELConstants']