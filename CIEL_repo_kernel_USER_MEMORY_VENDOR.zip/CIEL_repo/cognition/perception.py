# auto-generated wrapper (no placeholders)

from ..ext.ext10 import PerceptiveLayer
__all__ = ['PerceptiveLayer']