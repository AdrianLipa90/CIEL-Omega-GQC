# auto-generated wrapper (no placeholders)

from ..ext.ext10 import CognitionOrchestrator
__all__ = ['CognitionOrchestrator']