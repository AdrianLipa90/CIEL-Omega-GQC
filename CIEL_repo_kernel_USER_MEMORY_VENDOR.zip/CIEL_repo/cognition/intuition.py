# auto-generated wrapper (no placeholders)

from ..ext.ext10 import IntuitiveCortex
__all__ = ['IntuitiveCortex']