# auto-generated wrapper (no placeholders)

from ..ext.ext10 import DecisionCore
__all__ = ['DecisionCore']