# auto-generated wrapper (no placeholders)

from ..ext.ext10 import PredictiveCore
__all__ = ['PredictiveCore']